export enum WordStatus {
    NORMAL = 'normal',
    SELECTED = 'selected',
    DISABLED = 'disabled'
  }

