export enum GameDifficulty {
    HARD = 'hard',
    MEDIUM = 'medium',
    EASY = 'easy'
  }