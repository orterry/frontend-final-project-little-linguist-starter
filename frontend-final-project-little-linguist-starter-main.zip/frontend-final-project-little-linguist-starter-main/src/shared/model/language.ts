export enum Language {
    Hebrew = "Hebrew",
    English = "English"
}