export class TranslatedWord {
    guess:string;
    constructor(
        public origin : string,
        public target: string) 
        {
            this.guess=""
        }
}