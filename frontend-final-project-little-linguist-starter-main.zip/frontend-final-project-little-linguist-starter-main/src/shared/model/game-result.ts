
export class GameResult {
    constructor(
      public gamesCounter:number = 0,
      public pointCounter:number = 0
    ) {}
  }